// LMS/LessonRenderer/index.jsx
import React from "react";

import VideoLesson from "./VideoLesson";
import AudioLesson from "./AudioLesson";
import ArticleLesson from "./ArticleLesson";
import QuizLesson from "./QuizLesson";
import LiveLesson from "./LiveLesson";

const norm = (t) => String(t || "").trim().toLowerCase();

const RENDERERS = {
  video: VideoLesson,
  audio: AudioLesson,
  article: ArticleLesson,
  live: LiveLesson,
    // quiz / mock test aliases
 quiz: QuizLesson,
  test: QuizLesson,
  mocktest: QuizLesson,
  "mock-test": QuizLesson,
  "mock test": QuizLesson,
  "section quiz": QuizLesson,
  "section-quiz": QuizLesson,
  "section_quiz": QuizLesson,
  sectionquiz: QuizLesson,
};

const Fallback = ({ lesson }) => (
  <div className="alert alert-secondary">
    {/* <div className="fw-bold">{lesson?.title || "Lesson"}</div> */}
    <div className="text-muted small">Type: {lesson?.type || "unknown"}</div>
    <p className="mb-0">No renderer registered yet for this type.</p>
  </div>
);

export default function LessonRenderer({ lesson, course, ...rest }) {
  const key = norm(lesson?.type);
  const Comp = RENDERERS[key] || Fallback;
  // ⬇️ Forward all remaining props (e.g., onVideoEnded) without changing logic
  return <Comp lesson={lesson} course={course} {...rest} />;
}
