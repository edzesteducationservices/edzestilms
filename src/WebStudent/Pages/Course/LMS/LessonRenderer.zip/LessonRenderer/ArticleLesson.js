// // LMS/LessonRenderer/types/ArticleLesson.jsx
// import React, { useMemo } from "react";

// function isHtmlDataUrl(u = "") {
//   return /^data:text\/html[,;]/i.test(u);
// }
// function isPdf(u = "") {
//   return /\.pdf(\?|$)/i.test(u);
// }

// export default function ArticleLesson({ lesson }) {
//   const html = lesson?.meta?.html;
//   const reading = lesson?.meta?.readingTimeMinutes;
//   const fileUrl = lesson?.fileUrl;

//   const content = useMemo(() => {
//     if (html) return { mode: "html", value: html };
//     if (isHtmlDataUrl(fileUrl)) {
//       try {
//         const encoded = fileUrl.split(",")[1] || "";
//         const decoded = decodeURIComponent(atob(encoded));
//         return { mode: "html", value: decoded };
//       } catch {
//         return { mode: "frame", value: fileUrl };
//       }
//     }
//     if (fileUrl) {
//       if (isPdf(fileUrl)) return { mode: "frame", value: fileUrl };
//       // best-effort inline for plain pages
//       return { mode: "frame", value: fileUrl };
//     }
//     return { mode: "none", value: "" };
//   }, [html, fileUrl]);

//   return (
//     <div>
//       <h5 className="mb-2">{lesson?.title || "Article"}</h5>
//       {reading ? <div className="text-muted small mb-2">~{reading} min read</div> : null}

//       {content.mode === "html" && (
//         <div dangerouslySetInnerHTML={{ __html: content.value }} />
//       )}

//       {content.mode === "frame" && (
//         <iframe
//           title="article"
//           src={content.value}
//           style={{ width: "100%", minHeight: 600, border: "1px solid #e5e7eb", borderRadius: 6 }}
//         />
//       )}

//       {content.mode === "none" && (
//         <div className="alert alert-info">Article content not available.</div>
//       )}
//     </div>
//   );
// }




// LMS/LessonRenderer/types/ArticleLesson.jsx
import React, { useMemo, useEffect, useRef, useState } from "react";
import { getLessonProgress, markLessonComplete } from "../../../../utils/ProgressApi";
import "../article-editor.css"
// import "../LMS_Pages/LessonPlayerPage.css";

function isHtmlDataUrl(u = "") { return /^data:text\/html[,;]/i.test(u); }
function isPdf(u = "") { return /\.pdf(\?|$)/i.test(u); }

export default function ArticleLesson({ lesson, fullscreenTargetRef }) {
  const html = lesson?.meta?.html;
  const reading = lesson?.meta?.readingTimeMinutes;
  const fileUrl = lesson?.fileUrl;

  const [completed, setCompleted] = useState(false);

  const scrollerRef = useRef(null);
  const wrapRef = useRef(null);

  // ---------- Fullscreen state ----------
  const [isFs, setIsFs] = useState(
    !!(document.fullscreenElement || document.webkitFullscreenElement)
  );

  // ---------- Fullscreen helpers ----------
  const fsEnabled = () =>
    Boolean(document.fullscreenEnabled || document.webkitFullscreenEnabled);

  // Prefer the shared persistent host first; then fall back to this component's wrapper;
  // lastly to documentElement if allowed — keeps existing behavior otherwise.
  const chooseFsTarget = () => {
    if (fullscreenTargetRef?.current) return fullscreenTargetRef.current; // ✅ shared host
    if (fsEnabled()) return document.documentElement;
    return wrapRef.current || document.documentElement;
  };

  const requestFs = async (el) => {
    try {
      if (!el) return false;
      if (!fsEnabled() && el === document.documentElement) return false;
      if (document.fullscreenElement === el || document.webkitFullscreenElement === el) return true;
      if (el.requestFullscreen) { await el.requestFullscreen(); return true; }
      if (el.webkitRequestFullscreen) { await el.webkitRequestFullscreen(); return true; }
    } catch {
      // swallow permission / user gesture errors
    }
    return false;
  };

  const exitFs = async () => {
    try {
      if (document.exitFullscreen) await document.exitFullscreen();
      else if (document.webkitExitFullscreen) await document.webkitExitFullscreen();
    } catch {}
  };

  const toggleFs = async () => {
    const target = chooseFsTarget();
    const activeEl = document.fullscreenElement || document.webkitFullscreenElement;

    // If our target (or anything inside it) is currently fullscreen → exit
    if (activeEl && (activeEl === target || target?.contains?.(activeEl))) {
      await exitFs();
      return;
    }

    // Try preferred target; if denied, fall back to this component's wrapper
    const ok = await requestFs(target);
    if (!ok && target !== wrapRef.current) {
      await requestFs(wrapRef.current);
    }
  };

  // Keep isFs synced specifically with whether OUR chosen target (or its subtree) is in FS
  useEffect(() => {
    const sync = () => {
      const activeEl = document.fullscreenElement || document.webkitFullscreenElement;
      const target = chooseFsTarget();
      setIsFs(Boolean(activeEl && (activeEl === target || target?.contains?.(activeEl))));
    };
    // initialize and subscribe
    sync();
    document.addEventListener("fullscreenchange", sync);
    document.addEventListener("webkitfullscreenchange", sync);
    return () => {
      document.removeEventListener("fullscreenchange", sync);
      document.removeEventListener("webkitfullscreenchange", sync);
    };
  }, [fullscreenTargetRef]); // ✅ update if the shared host ref changes

  // ---------- Seed completion ----------
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        if (!lesson?._id) return;
        const saved = await getLessonProgress(lesson._id);
        if (alive) setCompleted(Boolean(saved?.completed));
      } catch {}
    })();
    return () => { alive = false; };
  }, [lesson?._id]);

  // ---------- Finish when scrolled near bottom ----------
  useEffect(() => {
    const el = scrollerRef.current;
    if (!el || completed) return;
    const onScroll = async () => {
      const atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight * 0.95;
      if (atBottom && !completed) {
        try { await markLessonComplete(lesson._id, true); setCompleted(true); } catch {}
      }
    };
    el.addEventListener("scroll", onScroll);
    return () => el.removeEventListener("scroll", onScroll);
  }, [completed, lesson?._id]);

  // ---------- Fallback timer for PDFs/cross-origin iframes ----------
  useEffect(() => {
    if (completed) return;
    const mins = Number(reading) > 0 ? Number(reading) : 2;
    const ms = Math.min(Math.max(mins * 60 * 1000 * 0.5, 20000), 90000);
    const t = setTimeout(async () => {
      if (!completed) {
        try { await markLessonComplete(lesson._id, true); setCompleted(true); } catch {}
      }
    }, ms);
    return () => clearTimeout(t);
  }, [completed, reading, lesson?._id]);

  // ---------- Content selection ----------
  const content = useMemo(() => {
    if (html) return { mode: "html", value: html };
    if (isHtmlDataUrl(fileUrl)) {
      try {
        const encoded = fileUrl.split(",")[1] || "";
        const decoded = decodeURIComponent(atob(encoded));
        return { mode: "html", value: decoded };
      } catch { return { mode: "frame", value: fileUrl }; }
    }
    if (fileUrl) return { mode: "frame", value: fileUrl };
    return { mode: "none", value: "" };
  }, [html, fileUrl]);

  // ---------- Height that respects fullscreen ----------
  const scrollerStyle = isFs
    ? { height: "100vh", overflow: "auto", borderRadius: 0 }
    : { maxHeight: 600, overflow: "auto", borderRadius: 6 };

  return (
    <div
      ref={wrapRef}
      className="lesson-overlay-wrap"
      onDoubleClickCapture={toggleFs}
      style={{ cursor: "zoom-in" }}
    >
      <h5 className="mb-2">{lesson?.title || "Article"}</h5>
      {reading ? <div className="text-muted small mb-2">~{reading} min read</div> : null}

      <div
        ref={scrollerRef}
        className="article-scroller"
        style={scrollerStyle}
      >
        {content.mode === "html" && (
          <div
            className="p-2"
            style={{ minHeight: isFs ? "100%" : undefined }}
            dangerouslySetInnerHTML={{ __html: content.value }}
          />
        )}

        {content.mode === "frame" && (
          <iframe
            title="article"
            src={content.value}
            style={{
              width: "100%",
              height: isFs ? "100%" : 600,
              border: "1px solid #e5e7eb",
              borderRadius: isFs ? 0 : 6,
              display: "block"
            }}
            allow="fullscreen"
            allowFullScreen
          />
        )}

        {content.mode === "none" && (
          <div className="alert alert-info m-0">Article content not available.</div>
        )}
      </div>
    </div>
  );
}
