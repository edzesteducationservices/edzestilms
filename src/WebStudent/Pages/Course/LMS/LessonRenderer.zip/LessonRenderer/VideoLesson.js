// // LMS/LessonRenderer/types/VideoLesson.jsx
// import React, { useState } from "react";
// import { coerceToSeconds, formatDuration } from "../LessonPreview";

// export default function VideoLesson({ lesson }) {
//   const [domSecs, setDomSecs] = useState(null);

//   const url = lesson?.videoUrl || lesson?.fileUrl;
//   const secs =
//     coerceToSeconds(lesson?.duration) ??
//     coerceToSeconds(lesson?.meta?.duration) ??
//     coerceToSeconds(lesson?.meta?.durationStr) ??
//     coerceToSeconds(lesson?.durationSeconds) ??
//     coerceToSeconds(lesson?.lengthSeconds) ??
//     coerceToSeconds(lesson?.durationMs) ??
//     coerceToSeconds(lesson?.isoDuration);

//   const effectiveSecs = secs || (Number.isFinite(domSecs) ? Math.round(domSecs) : null);
//   const display = formatDuration(effectiveSecs);

//   return (
//     <div>
      
//       {url ? (
//         <video
//           controls
//           src={url}
//           style={{ width: "100%", maxHeight: 540 }}
//           onLoadedMetadata={(e) => {
//             const d = e?.currentTarget?.duration;
//             if (Number.isFinite(d) && d > 0) setDomSecs(d);
//           }}
//         />
//       ) : (
//         <div className="alert alert-warning">Video URL not available.</div>
//       )}
//       {display ? <div className="text-muted small mt-2">Duration: {display}</div> : null}
//     </div>
//   );
// }








// LMS/LessonRenderer/types/VideoLesson.jsx
// import React, { useEffect, useRef } from "react";
// import axios from "axios";
// import { coerceToSeconds, formatDuration } from "../LessonPreview";

// const API = process.env.REACT_APP_API_URL;

// export default function VideoLesson({ lesson }) {
//   const url = lesson?.videoUrl || lesson?.fileUrl;
//   const secsFromDoc =
//     coerceToSeconds(lesson?.duration) ??
//     coerceToSeconds(lesson?.meta?.duration) ??
//     coerceToSeconds(lesson?.meta?.durationStr);

//   const videoRef = useRef(null);

//   // If the DB has no duration (or 0), try to grab it from the video element and persist once
//   useEffect(() => {
//     const v = videoRef.current;
//     if (!v || secsFromDoc) return;

//     const onMeta = async () => {
//       const d = Number.isFinite(v.duration) ? Math.round(v.duration) : 0;
//       if (d > 0) {
//         try {
//           const token = localStorage.getItem("token");
//           await axios.patch(
//             `${API}/api/courses/lessons/${lesson._id}/duration`,
//             { duration: d },
//             { headers: token ? { Authorization: `Bearer ${token}` } : {} }
//           );
//         } catch (e) {
//           // non-blocking; UI still works
//           console.warn("Could not persist duration:", e?.response?.data || e.message);
//         }
//       }
//     };

//     v.addEventListener("loadedmetadata", onMeta);
//     return () => v.removeEventListener("loadedmetadata", onMeta);
//   }, [lesson?._id, secsFromDoc]);

//   const display = secsFromDoc ? formatDuration(secsFromDoc) : null;

//   return (
//     <div>
//       <h5 className="mb-3">{lesson?.title || "Video"}</h5>
//       {url ? (
//         <video ref={videoRef} controls src={url} style={{ width: "100%", maxHeight: 540 }} />
//       ) : (
//         <div className="alert alert-warning">Video URL not available.</div>
//       )}
//       {/* {display ? <div className="text-muted small mt-2">Duration: {display}</div> : null} */}
//     </div>
//   );
// }










// import React from "react";
// import TrackedVideo from "../LMS_Pages/TrackedVideo"; // ← merged player
// import { coerceToSeconds, formatDuration } from "../LessonPreview"; // existing helpers

// export default function VideoLesson({ lesson, course, onVideoEnded }) {
//   const url = lesson?.videoUrl || lesson?.fileUrl;

//   // Keep original display computation (even if you don't show it)
//   const secs =
//     coerceToSeconds(lesson?.duration) ??
//     coerceToSeconds(lesson?.meta?.duration) ??
//     coerceToSeconds(lesson?.meta?.durationStr);
//   const display = secs ? formatDuration(secs) : null;

//   return (
//     <div>
//       {url ? (
//         <TrackedVideo
//           src={url}
//           // Helps the progress endpoint (courseSlug optional; sectionId unknown here)
//           courseSlug={course?.slug || ""}
//           sectionId={String(lesson.sectionId || "")}
//           lessonId={lesson?._id || ""}
//           autoPlay={false}
//           // duration persistence is built-in; safe to keep
//           persistDurationIfKnown={true}
//           // ⬇️ forward to trigger Up-Next overlay
//           onEnded={onVideoEnded}
          
//         />
//       ) : (
//         <div className="alert alert-warning">Video URL not available.</div>
//       )}
//       {/* Preserve original "no visible duration label" behavior */}
//       {/* {display ? <div className="text-muted small mt-2">Duration: {display}</div> : null} */}
//     </div>
//   );
// }






// import React from "react";
// import TrackedVideo from "../LMS_Pages/TrackedVideo"; // merged player
// import { coerceToSeconds, formatDuration } from "../LessonPreview"; // existing helpers

// export default function VideoLesson({ lesson, course, onVideoEnded }) {
//   // Prefer videoUrl, then fileUrl; ensure it's a trimmed string
//   const urlRaw = (lesson?.videoUrl ?? lesson?.fileUrl ?? "");
//   const url = typeof urlRaw === "string" ? urlRaw.trim() : "";

//   // Keep original display computation
//   const secs =
//     coerceToSeconds(lesson?.duration) ??
//     coerceToSeconds(lesson?.meta?.duration) ??
//     coerceToSeconds(lesson?.meta?.durationStr);
//   const display = secs ? formatDuration(secs) : null;

//   // Force a remount of the <video> when lesson changes
//   const videoKey = String(lesson?._id || url || "");

//   return (
//     <div>
//       {url ? (
//         <TrackedVideo
//           key={videoKey}
//           src={url}
//           courseSlug={course?.slug || ""}
//           sectionId={String(lesson?.sectionId || "")}
//           lessonId={String(lesson?._id || "")}
//           autoPlay={false}
//           // duration persistence is built-in; keep enabled
//           persistDurationIfKnown={true}
//           // Forward to trigger Up-Next overlay
//           onEnded={onVideoEnded}
//         />
//       ) : (
//         <div className="alert alert-warning">Video URL not available.</div>
//       )}

//       {/* Keep your original "no visible duration label" behavior */}
//       {/* {display ? <div className="text-muted small mt-2">Duration: {display}</div> : null} */}
//     </div>
//   );
// }




// import React from "react";
// import CustomVideoPlayer from "../Players/CustomVideoPlayer"; // ⬅️ swap in the custom player
// import "../Players/player.css"; // styles for the custom player
// import { coerceToSeconds, formatDuration } from "../LessonPreview"; // existing helpers

// export default function VideoLesson({ lesson, course, onVideoEnded, fullscreenTargetRef  }) {
//   // Prefer videoUrl, then fileUrl; ensure it's a trimmed string (UNCHANGED)
//   const urlRaw = (lesson?.videoUrl ?? lesson?.fileUrl ?? "");
//   const url = typeof urlRaw === "string" ? urlRaw.trim() : "";

//   // Keep original display computation (UNCHANGED; still not rendered)
//   const secs =
//     coerceToSeconds(lesson?.duration) ??
//     coerceToSeconds(lesson?.meta?.duration) ??
//     coerceToSeconds(lesson?.meta?.durationStr);
//   const display = secs ? formatDuration(secs) : null;

//   // Force a remount of the player when lesson/src changes (UNCHANGED)
//   const videoKey = String(lesson?._id || url || "");

//   return (
//     <div>
//       {url ? (
//         <CustomVideoPlayer
//           key={videoKey}
//           src={url}
//           // parity with previous behavior:
//           autoPlay={false}                       // keep as false (no logic change)
//           lessonId={String(lesson?._id || "")}   // identifiers preserved
//           courseSlug={course?.slug || ""}
//           // sectionId was previously passed to TrackedVideo; CustomVideoPlayer
//           // doesn't use it, but keeping it here has no impact on logic:
//           sectionId={String(lesson?.sectionId || "")}
//           // duration persistence kept enabled (same intent as before)
//           persistDurationIfKnown={true}
//           persistProgress={true}
//           // optional poster passthrough (non-breaking; safe to include or omit)
//           poster={lesson?.meta?.poster}
//           // Forward end to trigger your Up-Next overlay (UNCHANGED)
//           onEnded={onVideoEnded}
//           fullscreenTargetRef={fullscreenTargetRef} 
//         />
//       ) : (
//         <div className="alert alert-warning">Video URL not available.</div>
//       )}

//       {/* Keep your original "no visible duration label" behavior */}
//       {/* {display ? <div className="text-muted small mt-2">Duration: {display}</div> : null} */}
//     </div>
//   );
// }





// LMS/LessonRenderer/VideoLesson.js
import React, { useMemo } from "react";
import CustomVideoPlayer from "../Players/CustomVideoPlayer";
import "../Players/player.css";
import { coerceToSeconds, formatDuration } from "../LessonPreview";

// Try many places/structures to find a usable URL
function resolveVideoUrl(lesson, props) {
  const pick = (v) => {
    if (!v) return "";
    if (typeof v === "string") return v.trim();
    if (typeof v === "object") {
      if (typeof v.secure_url === "string" && v.secure_url.trim()) return v.secure_url.trim();
      if (typeof v.url === "string" && v.url.trim()) return v.url.trim();
    }
    return "";
  };

  const candidates = [
    props?.src,                // if someone passed src directly
    props?.videoUrl,
    props?.fileUrl,

    lesson?.videoUrl,
    lesson?.fileUrl,
    lesson?.url,
    lesson?.source,

    // common nested shapes
    lesson?.video?.url,
    lesson?.file?.url,
    lesson?.cloudinary?.secure_url,
    lesson?.cloudinary?.url,
    lesson?.meta?.videoUrl,
    lesson?.meta?.fileUrl,
    lesson?.meta?.url,
  ];

  for (const c of candidates) {
    const got = pick(c);
    if (got) return got;
  }
  return "";
}

export default function VideoLesson({ lesson, course, onVideoEnded, fullscreenTargetRef, ...rest }) {
  const url = useMemo(() => resolveVideoUrl(lesson, rest), [lesson, rest]);

  const secs =
    coerceToSeconds(lesson?.duration) ??
    coerceToSeconds(lesson?.meta?.duration) ??
    coerceToSeconds(lesson?.meta?.durationStr);
  const display = secs ? formatDuration(secs) : null;

  // Remount player if lesson/src changes
  const videoKey = String(lesson?._id || url || "");

  return (
    <div>
      {url ? (
       
        <CustomVideoPlayer
  key={videoKey}
  src={url}
  autoPlay={false}
  lessonId={String(lesson?._id || "")}
  courseSlug={course?.slug || ""}
  sectionId={String(lesson?.sectionId || "")}  // ← now used
  persistDurationIfKnown
  persistProgress
  poster={lesson?.meta?.poster}
  onEnded={onVideoEnded}
  fullscreenTargetRef={fullscreenTargetRef}
/>
      ) : (
        <div className="alert alert-warning">Video URL not available.</div>
      )}

      {/* {display ? <div className="text-muted small mt-2">Duration: {display}</div> : null} */}
    </div>
  );
}
